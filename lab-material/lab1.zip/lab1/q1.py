
# Todo 1: Define a function to calculate the volume of a sphere
def calc_volume(r):
    """Returns the volume of a sphere with radius r."""
    volume = 0
    return volume

# Todo 2: Define a function to calculate the surface area of a sphere
def calc_surface_area(r):
    """Returns the surface area of a sphere with radius r."""
    surface_area = 0
    return surface_area

radius = 2

# Todo 3: Call the functions and print the results
