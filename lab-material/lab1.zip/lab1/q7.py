import numpy as np

# Todo 1: Create required numpy arrays

# Todo 2: Calculated required multiplication



