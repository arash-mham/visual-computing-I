import numpy as np

# Todo 1: Create required numpy array

# Todo 2: Manipulate the array into desired format using array slicing


