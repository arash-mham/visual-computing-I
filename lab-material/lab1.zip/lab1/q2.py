
iterations = 1000000

# Todo 1: Define a function to calculate the volume of a sphere
pi = 0

print("Pi is approximately", pi, "after", iterations, "iterations")