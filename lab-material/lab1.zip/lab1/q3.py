import random

# Todo 1: Set a seed
    
# Todo 2: weighted_sum using for loop
def weighted_sum_1(weights, values):
    """Calculate weighted sum using for loop"""
    
# Todo 3: weighted_sum using list comprehension
def weighted_sum_2(weights, values):
    """Calculate weighted sum using list comprehension"""
    
# Define main function
def main():
    pass
    # Todo 4: Generate random weights and values


if __name__ == "__main__":
    main()