
# Paste the code from q4.py here


# Todo 1: Write student grades in CSV format
with open("grades.csv", "w") as f:
    pass

# Todo 2: Write student grades in JSON format
import json
