import numpy as np
import cv2


if __name__ == '__main__':
    ##read source image

    ##implement reconstruction
    raise NotImplementedError