import torch
import torch.nn as nn
import torch.nn.functional as F

#import any other libraries you need below this line

class twoConvBlock(nn.Module):
  def __init__(self):
    super(twoConvBlock, self).__init__()
    #todo
    #initialize the block

  def forward(self):
    #todo
    #implement the forward path

class downStep(nn.Module):
  def __init__(self):
    super(downStep, self).__init__()
    #todo
    #initialize the down path

  def forward(self):
    #todo
    #implement the forward path

class upStep(nn.Module):
  def __init__(self):
    super(upStep, self).__init__()
    #todo
    #initialize the up path

  def forward(self):
    #todo
    #implement the forward path

class UNet(nn.Module):
  def __init__(self):
    super(upStep, self).__init__()
    #todo
    #initialize the complete model

   def forward(self):
    #todo
    #implement the forward path



